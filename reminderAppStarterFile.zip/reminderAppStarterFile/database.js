let Database = {
    cindy: {
        reminders: [{id: 1, title: "abc", description: "abcabc", completed: false}]
    },
    alex: {
        reminders: []
    } 
}

module.exports = Database;